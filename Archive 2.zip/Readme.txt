Thanks for downloading this theme!

Theme Name: Baker
Theme URL: https://bootstrapmade.com/baker-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com